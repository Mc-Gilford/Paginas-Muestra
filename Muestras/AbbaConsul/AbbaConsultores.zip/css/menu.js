window.onscroll = function() {scrollFunction()};


function scrollFunction() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
      document.getElementById("menu").style.position = "fixed";
    } else {
      document.getElementById("menu").style.removeProperty("position");
    }
}